# TPA

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**passthrough** | **bool** |  | [optional] [default to False]
**concepts** | [**list[Concept]**](Concept.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

