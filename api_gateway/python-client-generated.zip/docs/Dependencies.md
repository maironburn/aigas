# Dependencies

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dependency_type** | **str** | Posibles valores Product, Settlement Line | [optional] 
**product** | **str** |  | [optional] 
**dependent_attribute** | **str** |  | [optional] 
**dependency_calc** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

