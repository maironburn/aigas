# Calendar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calendar_when_days** | **str** |  | [optional] 
**calendar_liq_period** | **str** |  | [optional] 
**calendar_calc_sub_period** | **str** |  | [optional] 
**invoice_calendar** | [**InvoiceCalendar**](InvoiceCalendar.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

