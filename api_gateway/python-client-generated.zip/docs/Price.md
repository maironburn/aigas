# Price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price_type** | **str** |  | [optional] 
**formula** | **str** |  | [optional] 
**margin** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

