# Threshold

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_from** | **date** |  | [optional] 
**to** | **date** |  | [optional] 
**limit_to** | **float** |  | [optional] 
**type** | **str** | Posibles valores Abs, %. Para Bonificacion por nominacion solo %. | [optional] 
**formula** | **str** |  | [optional] 
**margin** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

