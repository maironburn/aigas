# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_code** | **str** |  | 
**product_version** | **str** | productVersion | 
**status** | **str** | Posibles valores Draft, Active, Old, Cancelled | 
**previous_status** | **str** | previousStatus | [optional] 
**type** | **str** | type | 
**subtype** | **str** | subtype | [optional] 
**description_bill_fix** | **str** | descriptionBillFix | 
**description_bill_free** | **str** | descriptionBillFree | 
**nav_concept** | **str** | navConcept | 
**bill_section** | **str** | billSection | [optional] 
**start_date** | **date** |  | [optional] 
**update_start_date_with_cli** | **bool** |  | [optional] [default to False]
**end_date** | **date** |  | [optional] 
**update_end_date_with_cli** | **bool** |  | [optional] [default to False]
**last_settlement_date** | **date** |  | [optional] 
**meta** | [**Meta**](Meta.md) |  | [optional] 
**calendars** | [**Calendar**](Calendar.md) |  | 
**currency** | **str** | Posibles valores EUR, USD, GBP | 
**units** | **str** | Posibles valores MWh, kWh, MMBTU, Gj | 
**_lambda** | **str** |  | [optional] 
**dependencies** | [**list[Dependencies]**](Dependencies.md) |  | [optional] 
**offsets** | [**list[Offsets]**](Offsets.md) |  | [optional] 
**split_type** | **str** | Posibles valores FixPercentage,Forecast,BestConsumption,MoleculeService | 
**cl_is** | [**list[Cli]**](Cli.md) |  | 
**prices** | [**Price**](Price.md) |  | [optional] 
**quantities** | [**list[Quantity]**](Quantity.md) | Para Bloque Firme, Cobertura y Tolerancia solo tiene un elemento, para Servicio de Molecula puede tener entre 0 y el total de thresholds | [optional] 
**thresholds** | [**list[Threshold]**](Threshold.md) | Bandas del Servicio de Molecula, margenes de error de la Bonificacion por nominacion. Para limite de Tolerancia solo admite un elemento | [optional] 
**molecule_taxes** | [**list[MoleculeTax]**](MoleculeTax.md) | Para Bloque Firme y Servicio de Molecula | [optional] 
**fees** | [**Fee**](Fee.md) |  | [optional] 
**digital_payment** | [**DigitalPayment**](DigitalPayment.md) |  | [optional] 
**fix_prices** | [**list[Range]**](Range.md) |  | [optional] 
**tpa** | [**TPA**](TPA.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

