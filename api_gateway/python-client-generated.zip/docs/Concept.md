# Concept

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**subtype** | **str** |  | [optional] 
**qds** | [**list[Qd]**](Qd.md) |  | [optional] 
**qd_calctype** | **str** |  | [optional] 
**qd_m_1** | **float** |  | [optional] 
**qd_m_2** | **float** |  | [optional] 
**toll_presure_group** | **float** |  | [optional] 
**toll_consumption_step** | **float** |  | [optional] 
**vt_price** | [**Price**](Price.md) |  | [optional] 
**ft_price** | [**Price**](Price.md) |  | [optional] 
**transport_fix_term_price** | [**Range**](Range.md) |  | [optional] 
**regas_fix_term_price** | [**Range**](Range.md) |  | [optional] 
**type** | **str** |  | [optional] 
**amounts** | [**list[Amount]**](Amount.md) |  | [optional] 
**cod_concepto_b70in** | **list[float]** |  | [optional] 
**cod_concepto_b70out** | **list[float]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

