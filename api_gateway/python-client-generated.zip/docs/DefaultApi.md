# swagger_client.DefaultApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_post**](DefaultApi.md#product_post) | **POST** /product | tracker de productos
[**search_products**](DefaultApi.md#search_products) | **GET** /list | search products

# **product_post**
> product_post(body=body)

tracker de productos

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.Product() # Product |  (optional)

try:
    # tracker de productos
    api_instance.product_post(body=body)
except ApiException as e:
    print("Exception when calling DefaultApi->product_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Product**](Product.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_products**
> list[Product] search_products(product_code=product_code, startdate=startdate, enddate=enddate)

search products

By passing in the appropriate options, you can search for available products in the system 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
product_code = 'product_code_example' # str | pass an optional search string for looking up inventory (optional)
startdate = '2013-10-20' # date | search by startdate (optional)
enddate = '2013-10-20' # date | search by end date (optional)

try:
    # search products
    api_response = api_instance.search_products(product_code=product_code, startdate=startdate, enddate=enddate)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->search_products: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_code** | **str**| pass an optional search string for looking up inventory | [optional] 
 **startdate** | **date**| search by startdate | [optional] 
 **enddate** | **date**| search by end date | [optional] 

### Return type

[**list[Product]**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

