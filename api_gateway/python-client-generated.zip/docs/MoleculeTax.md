# MoleculeTax

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**molecule_tax_concept** | **str** |  | [optional] 
**molecule_tax_value** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

