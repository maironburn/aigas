# Meta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta01** | **str** |  | [optional] 
**meta02** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

