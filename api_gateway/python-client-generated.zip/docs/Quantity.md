# Quantity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_from** | **date** |  | [optional] 
**to** | **date** |  | [optional] 
**quantity** | **float** |  | [optional] 
**type** | **str** | Cobertura y Tolerancia. Posibles valores Abs, % | [optional] 
**reference** | **str** | Cobertura y Tolerancia//Posibles valores Forecast,BestConsumption. Si Type&#x3D;Abs , Abs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

