# InvoiceCalendar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calendar_inv_days** | **list[date]** |  | [optional] 
**dynamic_inv_calendar** | **str** |  | [optional] 
**invoice_calendar_liq_offset** | [**InvoiceCalendarLiqOffset**](InvoiceCalendarLiqOffset.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

