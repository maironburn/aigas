import connexion
import six

from swagger_server.models.product import Product  # noqa: E501
from swagger_server import util


def product_post(body=None):  # noqa: E501
    """tracker de productos

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Product.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def search_products(product_code=None, startdate=None, enddate=None):  # noqa: E501
    """search products

    By passing in the appropriate options, you can search for available products in the system  # noqa: E501

    :param product_code: pass an optional search string for looking up inventory
    :type product_code: str
    :param startdate: search by startdate
    :type startdate: str
    :param enddate: search by end date
    :type enddate: str

    :rtype: List[Product]
    """
    startdate = util.deserialize_date(startdate)
    enddate = util.deserialize_date(enddate)
    return 'do some magic!'
