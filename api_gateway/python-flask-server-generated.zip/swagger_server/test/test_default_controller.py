# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.product import Product  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_product_post(self):
        """Test case for product_post

        tracker de productos
        """
        body = Product()
        response = self.client.open(
            '/product',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_search_products(self):
        """Test case for search_products

        search products
        """
        query_string = [('product_code', 'product_code_example'),
                        ('startdate', '2013-10-20'),
                        ('enddate', '2013-10-20')]
        response = self.client.open(
            '/list',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
